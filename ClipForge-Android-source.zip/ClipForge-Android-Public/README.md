# ClipForge Android

A starter Android app for creating MP4 segments from videos stored on the phone.

## Current MVP
- Pick a video with Android's system file picker.
- Set start and end times in seconds.
- Export that segment as an MP4 using AndroidX Media3 Transformer.

## Not included yet
This is not yet a full AI OpusClip replacement. Automatic highlight detection, speech transcription, animated captions, smart 9:16 reframing, YouTube URL downloading, and automatic YouTube publishing are not implemented.

## Build
Use JDK 17 and Android SDK 35, or download the debug APK from the successful GitHub Actions workflow artifact.
