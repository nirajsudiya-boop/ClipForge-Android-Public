package com.clipforge.android;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 41;
    private Uri selectedVideo;
    private long durationMs;
    private EditText startSeconds, endSeconds;
    private TextView fileStatus, resultStatus;
    private Button exportButton;
    private Transformer transformer;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24));
        root.setBackgroundColor(0xFFF7F8FC);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("ClipForge"); title.setTextSize(30);
        title.setTextColor(0xFF172554); title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1); root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Turn a long video into a short clip");
        subtitle.setTextSize(15); subtitle.setTextColor(0xFF475569);
        subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0, dp(6), 0, dp(22));
        root.addView(subtitle);

        Button pick = new Button(this);
        pick.setText("Choose video from phone"); root.addView(pick);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("video/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_VIDEO);
        });

        fileStatus = new TextView(this);
        fileStatus.setText("No video selected"); fileStatus.setTextSize(14);
        fileStatus.setTextColor(0xFF334155); fileStatus.setPadding(0, dp(12), 0, dp(18));
        root.addView(fileStatus);

        addLabel(root, "Start time (seconds)");
        startSeconds = new EditText(this); startSeconds.setSingleLine(true);
        startSeconds.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        startSeconds.setText("0"); root.addView(startSeconds);

        addLabel(root, "End time (seconds)");
        endSeconds = new EditText(this); endSeconds.setSingleLine(true);
        endSeconds.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        root.addView(endSeconds);

        exportButton = new Button(this); exportButton.setText("Create clip");
        exportButton.setEnabled(false); root.addView(exportButton);
        exportButton.setOnClickListener(v -> exportClip());

        resultStatus = new TextView(this);
        resultStatus.setText("Exported MP4 will be saved in ClipForge's Movies folder.");
        resultStatus.setTextSize(14); resultStatus.setTextColor(0xFF166534);
        resultStatus.setPadding(0, dp(16), 0, dp(16)); root.addView(resultStatus);

        TextView note = new TextView(this);
        note.setText("First version: manual video trimming on your phone. AI highlight detection, captions, 9:16 reframing and direct YouTube downloading are not included yet. Only edit videos you own or have permission to use.");
        note.setTextSize(13); note.setTextColor(0xFF64748B);
        note.setPadding(0, dp(14), 0, 0); root.addView(note);
        setContentView(scroll);
    }

    private void addLabel(LinearLayout root, String value) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(14);
        t.setTextColor(0xFF1E293B); t.setPadding(0, dp(12), 0, dp(4)); root.addView(t);
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_VIDEO || result != RESULT_OK || data == null || data.getData() == null) return;
        selectedVideo = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(selectedVideo, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, selectedVideo);
            String raw = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            durationMs = raw == null ? 0 : Long.parseLong(raw);
            long sec = durationMs / 1000;
            fileStatus.setText("Video selected • " + String.format(Locale.US, "%d min %d sec", sec / 60, sec % 60));
            endSeconds.setText(String.valueOf(sec));
            exportButton.setEnabled(durationMs > 1000);
        } catch (Exception e) {
            fileStatus.setText("Could not read this video. Choose another file.");
            exportButton.setEnabled(false);
        } finally {
            try { retriever.release(); } catch (Exception ignored) { }
        }
    }

    private void exportClip() {
        if (selectedVideo == null) return;
        try {
            double start = Double.parseDouble(startSeconds.getText().toString().trim());
            double end = Double.parseDouble(endSeconds.getText().toString().trim());
            long from = (long)(start * 1000), to = (long)(end * 1000);
            if (start < 0 || to <= from || to > durationMs) {
                resultStatus.setText("Enter a valid range within the video duration."); return;
            }
            File folder = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (folder == null) throw new IllegalStateException("Storage folder unavailable");
            if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Cannot create output folder");
            File output = new File(folder, "ClipForge_" + System.currentTimeMillis() + ".mp4");
            MediaItem.ClippingConfiguration clip = new MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(from).setEndPositionMs(to).build();
            MediaItem item = new MediaItem.Builder().setUri(selectedVideo)
                    .setClippingConfiguration(clip).build();
            EditedMediaItem edited = new EditedMediaItem.Builder(item).build();
            exportButton.setEnabled(false);
            resultStatus.setText("Creating clip… Keep the app open.");
            transformer = new Transformer.Builder(this).addListener(new Transformer.Listener() {
                @Override public void onCompleted(Composition composition, ExportResult exportResult) {
                    exportButton.setEnabled(true);
                    resultStatus.setText("Clip created! Saved at:\n" + output.getAbsolutePath());
                }
                @Override public void onError(Composition composition, ExportResult exportResult, ExportException error) {
                    exportButton.setEnabled(true);
                    resultStatus.setText("Export failed: " + error.getMessage());
                }
            }).build();
            transformer.start(edited, output.getAbsolutePath());
        } catch (NumberFormatException e) {
            resultStatus.setText("Enter start and end times in seconds.");
        } catch (Exception e) {
            exportButton.setEnabled(true); resultStatus.setText("Could not export: " + e.getMessage());
        }
    }
}
